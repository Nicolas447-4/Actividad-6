// Crea una conexión WebSocket con el servidor usando la dirección actual del navegador (localhost:8080)
const ws = new WebSocket(`ws://${location.host}`);

// Obtiene las referencias a los elementos HTML donde se mostrarán los mensajes y se escribirá el texto
const messagesDiv = document.getElementById("messages");
const input = document.getElementById("messageInput");

// Se ejecuta cada vez que llega un mensaje del servidor
ws.onmessage = (event) => {
  const msg = document.createElement("div"); // Crea un nuevo <div> para el mensaje
  msg.textContent = event.data; // Asigna el contenido del mensaje recibido
  messagesDiv.appendChild(msg); // Agrega el mensaje al contenedor
  messagesDiv.scrollTop = messagesDiv.scrollHeight; // Desplaza hacia abajo para mostrar el último mensaje
};

// Función que envía el mensaje escrito por el usuario al servidor
function sendMessage() {
  if (input.value.trim() !== "") { // Verifica que no esté vacío el mensaje
    ws.send(input.value); // Envía el mensaje al servidor WebSocket
    input.value = ""; // Limpia el campo de entrada
  }
}
