// Importa las dependencias necesarias
const express = require('express');             // Framework web para servir archivos estáticos
const http = require('http');                   // Módulo HTTP nativo de Node.js
const WebSocket = require('ws');                // Librería para WebSockets
const { v4: uuidv4 } = require('uuid');         // Generador de UUIDs para nombres de usuario únicos

// Crea una aplicación Express
const app = express();

// Crea un servidor HTTP y lo asocia con la app de Express
const server = http.createServer(app);

// Crea un servidor WebSocket conectado al servidor HTTP
const wss = new WebSocket.Server({ server });

// Mapa para guardar conexiones WebSocket junto con sus nombres de usuario
const clients = new Map();

// Sirve archivos estáticos desde la carpeta "public"
app.use(express.static('public'));

// Evento que se dispara cada vez que un cliente se conecta vía WebSocket
wss.on('connection', (ws) => {
  // Genera un nombre de usuario temporal único (por ejemplo: Usuario_3fa2e7d1)
  const userId = uuidv4().slice(0, 8); // toma solo los primeros 8 caracteres
  const username = `Usuario_${userId}`;

  // Guarda la conexión y su nombre de usuario
  clients.set(ws, username);

  // Notifica a todos que un nuevo usuario se ha unido
  broadcast(`${username} se ha unido al chat.`);

  // Evento cuando el cliente envía un mensaje
  ws.on('message', (message) => {
    broadcast(`${username}: ${message}`);
  });

  // Evento cuando un cliente se desconecta
  ws.on('close', () => {
    broadcast(`${username} se ha desconectado.`);
    clients.delete(ws); // Elimina al usuario del mapa
  });
});

// Función para enviar un mensaje a todos los clientes conectados
function broadcast(message) {
  for (const client of clients.keys()) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message); // Envía el mensaje si la conexión está abierta
    }
  }
}

// Define el puerto (usa 8080 por defecto si no se especifica en el entorno)
const PORT = process.env.PORT || 8080;

// Inicia el servidor HTTP y WebSocket
server.listen(PORT, () => {
  console.log(`Servidor iniciado en http://localhost:${PORT}`);
});
